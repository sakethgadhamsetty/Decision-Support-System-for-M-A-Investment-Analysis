# DSS — Decision Support System (React Version)

## How to Run in VS Code

### Step 1 — Open folder in VS Code
File → Open Folder → select the `dss-react` folder

### Step 2 — Open Terminal in VS Code
Terminal → New Terminal (or press Ctrl + `)

### Step 3 — Install dependencies
```
npm install
```

### Step 4 — Start the app
```
npm run dev
```

### Step 5 — Open in browser
Go to: http://localhost:5173

---

## Project Structure
```
dss-react/
├── index.html              ← Entry HTML
├── package.json            ← Dependencies
├── vite.config.js          ← Vite config
└── src/
    ├── main.jsx            ← React entry point
    ├── App.jsx             ← Page router
    ├── index.css           ← Global styles
    ├── pages/
    │   ├── Landing.jsx     ← Landing page
    │   ├── Login.jsx       ← Login/Signup page
    │   ├── Chat.jsx        ← Chat interface
    │   └── Evaluation.jsx  ← 15-term evaluation
    └── components/
        └── Sidebar.jsx     ← Shared sidebar
```

## Pages
1. **Landing** → Decision Support System hero page
2. **Login** → Sign In / Sign Up / Guest
3. **Chat** → ChatGPT-style deal query interface
4. **Evaluation** → 15-term structured evaluation framework

## Notes
- Node.js required (download from nodejs.org LTS)
- Runs on port 5173 by default
- PASS/FAIL is system-derived (not user-clickable)
