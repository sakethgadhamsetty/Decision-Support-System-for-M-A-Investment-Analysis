import { useState } from 'react'

export default function Login({ goTo }) {
  const [tab, setTab] = useState('si')

  return (
    <div style={{position:'fixed',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',overflow:'hidden',background:'var(--bg)'}}>
      <div style={{position:'absolute',width:480,height:480,borderRadius:'50%',background:'rgba(74,127,245,.07)',top:-100,right:'8%',filter:'blur(110px)',pointerEvents:'none'}}/>
      <div style={{position:'absolute',width:320,height:320,borderRadius:'50%',background:'rgba(99,102,241,.05)',bottom:-60,left:'8%',filter:'blur(100px)',pointerEvents:'none'}}/>

      <button onClick={()=>goTo('landing')} style={{position:'absolute',top:18,left:18,display:'flex',alignItems:'center',gap:5,fontSize:12,color:'var(--t3)',background:'none',border:'none',cursor:'pointer',zIndex:10,transition:'.2s'}}>
        ← Back
      </button>

      <div style={{position:'relative',zIndex:2,width:'100%',maxWidth:390,padding:'0 18px',animation:'fu .4s ease both'}}>
        {/* Logo mark */}
        <div style={{display:'flex',flexDirection:'column',alignItems:'center',marginBottom:28}}>
          <div style={{width:46,height:46,borderRadius:13,background:'var(--blue-g)',display:'flex',alignItems:'center',justifyContent:'center',marginBottom:12,boxShadow:'0 0 36px rgba(74,127,245,.25)'}}>
            <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
            </svg>
          </div>
          <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:14,fontWeight:700,color:'var(--t2)',letterSpacing:'.2em',textTransform:'uppercase',marginBottom:3}}>Decision Support System</h1>
          <h2 style={{fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:900,color:'#fff',marginBottom:3}}>DSS <span style={{color:'var(--t3)',fontWeight:400,fontSize:14}}>·</span> InvestIQ</h2>
          <p style={{fontSize:11,color:'var(--t3)'}}>M&A Investment Analysis Platform</p>
        </div>

        {/* Card */}
        <div style={{background:'var(--s1)',border:'1px solid var(--b1)',borderRadius:'var(--rl)',padding:26,marginBottom:12}}>
          {/* Tabs */}
          <div style={{display:'flex',background:'var(--s2)',borderRadius:8,padding:3,marginBottom:22}}>
            {[['si','Sign In'],['su','Sign Up']].map(([id,label])=>(
              <button key={id} onClick={()=>setTab(id)}
                style={{flex:1,padding:'7px 12px',borderRadius:6,fontSize:12,fontWeight:500,background:tab===id?'var(--s3)':'transparent',color:tab===id?'var(--t1)':'var(--t2)',boxShadow:tab===id?'0 1px 5px rgba(0,0,0,.3)':'none',transition:'.2s',border:'none',cursor:'pointer'}}>
                {label}
              </button>
            ))}
          </div>

          {tab === 'si' && (
            <div>
              <Field label="Email" type="email" placeholder="you@firm.com"/>
              <Field label="Password" type="password" placeholder="••••••••"/>
              <button onClick={()=>goTo('chat')} style={btnMain}>Sign In</button>
              <OrDivider/>
              <button onClick={()=>goTo('chat')} style={btnGhost}>Continue as Guest</button>
            </div>
          )}
          {tab === 'su' && (
            <div>
              <Field label="Full Name" type="text" placeholder="Your full name"/>
              <Field label="Email" type="email" placeholder="you@firm.com"/>
              <Field label="Password" type="password" placeholder="Create password"/>
              <button onClick={()=>goTo('chat')} style={btnMain}>Create Account</button>
              <OrDivider/>
              <button onClick={()=>goTo('chat')} style={btnGhost}>Continue as Guest</button>
            </div>
          )}
        </div>

        <p style={{textAlign:'center',fontSize:11,color:'var(--t3)',lineHeight:1.6}}>
          By continuing you agree to our <a href="#" style={{color:'var(--blue)',opacity:.75}}>Terms</a> and <a href="#" style={{color:'var(--blue)',opacity:.75}}>Privacy Policy</a>
        </p>
      </div>
    </div>
  )
}

function Field({ label, type, placeholder }) {
  return (
    <div style={{marginBottom:12}}>
      <label style={{display:'block',fontSize:11,fontWeight:500,color:'var(--t2)',marginBottom:5,letterSpacing:'.02em'}}>{label}</label>
      <input type={type} placeholder={placeholder}
        style={{width:'100%',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:8,padding:'9px 12px',fontSize:13,color:'var(--t1)'}}/>
    </div>
  )
}

function OrDivider() {
  return (
    <div style={{display:'flex',alignItems:'center',gap:10,margin:'12px 0'}}>
      <div style={{flex:1,height:1,background:'var(--b1)'}}/>
      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',letterSpacing:'.06em'}}>or</span>
      <div style={{flex:1,height:1,background:'var(--b1)'}}/>
    </div>
  )
}

const btnMain = {width:'100%',padding:10,background:'var(--blue-g)',borderRadius:8,color:'#fff',fontSize:13,fontWeight:500,marginBottom:12,border:'none',cursor:'pointer',boxShadow:'0 4px 16px rgba(74,127,245,.15)'}
const btnGhost = {width:'100%',padding:10,background:'transparent',border:'1px solid var(--b1)',borderRadius:8,color:'var(--t2)',fontSize:13,fontWeight:500,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:7}
