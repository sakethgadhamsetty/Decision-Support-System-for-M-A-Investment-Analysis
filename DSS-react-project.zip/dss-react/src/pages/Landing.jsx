export default function Landing({ goTo }) {
  return (
    <div style={{position:'fixed',inset:0,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',overflow:'hidden',background:'var(--bg)'}}>
      {/* Orbs */}
      <div style={{position:'absolute',width:650,height:650,borderRadius:'50%',background:'rgba(74,127,245,.07)',top:-180,right:-80,filter:'blur(130px)',pointerEvents:'none'}}/>
      <div style={{position:'absolute',width:450,height:450,borderRadius:'50%',background:'rgba(99,102,241,.05)',bottom:-120,left:-60,filter:'blur(130px)',pointerEvents:'none'}}/>
      {/* Grid */}
      <div style={{position:'absolute',inset:0,backgroundImage:'linear-gradient(#0e0e1c 1px,transparent 1px),linear-gradient(90deg,#0e0e1c 1px,transparent 1px)',backgroundSize:'72px 72px',maskImage:'radial-gradient(ellipse 75% 75% at 50% 50%,black 20%,transparent 100%)',opacity:.5,pointerEvents:'none'}}/>

      <div style={{position:'relative',zIndex:2,display:'flex',flexDirection:'column',alignItems:'center',textAlign:'center',maxWidth:660,padding:'0 28px'}}>
        {/* Pill */}
        <div style={{display:'inline-flex',alignItems:'center',gap:7,padding:'5px 16px',borderRadius:50,border:'1px solid #252540',background:'rgba(255,255,255,.02)',marginBottom:28,animation:'fu .6s ease both'}}>
          <div style={{width:5,height:5,borderRadius:'50%',background:'var(--blue)',boxShadow:'0 0 8px var(--blue)',animation:'pulse 2s infinite'}}/>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:'var(--t2)',letterSpacing:'.12em',textTransform:'uppercase'}}>M&A Investment Analysis</span>
        </div>

        {/* Small label */}
        <div style={{fontFamily:"'Playfair Display',serif",fontSize:'clamp(11px,1.4vw,14px)',fontWeight:400,color:'var(--t3)',letterSpacing:'.25em',textTransform:'uppercase',marginBottom:12,animation:'fu .6s .05s ease both'}}>
          Powered by InvestIQ
        </div>

        {/* Big title */}
        <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:'clamp(44px,7.5vw,78px)',fontWeight:900,lineHeight:.92,letterSpacing:'-.02em',color:'#fff',marginBottom:10,animation:'fu .6s .1s ease both'}}>
          Decision<br/>
          <em style={{fontStyle:'italic',background:'var(--blue-g)',WebkitBackgroundClip:'text',WebkitTextFillColor:'transparent',backgroundClip:'text'}}>Support</em><br/>
          System
        </h1>

        <div style={{fontFamily:"'Playfair Display',serif",fontSize:'clamp(16px,2.2vw,22px)',fontWeight:700,color:'var(--t2)',letterSpacing:'.05em',textTransform:'uppercase',marginBottom:10,animation:'fu .6s .15s ease both'}}>
          DSS · Investment Intelligence
        </div>
        <p style={{fontSize:14,fontWeight:300,fontStyle:'italic',color:'var(--t3)',marginBottom:42,animation:'fu .6s .2s ease both'}}>
          Intelligent analysis for investments that matter
        </p>

        {/* Feature lines */}
        <div style={{display:'flex',flexDirection:'column',gap:9,width:'100%',maxWidth:460,marginBottom:48,animation:'fu .6s .25s ease both'}}>
          {[
            {icon:'📈',title:'Investment Growth Analysis',sub:'Evaluate growth potential and return on investment across key financial dimensions'},
            {icon:'🏦',title:'M&A Deal Evaluation',sub:'Structured scoring for mergers, acquisitions and private equity transactions'},
            {icon:'⚡',title:'Supports Decision Making',sub:'Data-driven verdicts to support confident, well-reasoned investment decisions'},
          ].map((f,i)=>(
            <div key={i} style={{display:'flex',alignItems:'center',gap:13,padding:'13px 18px',background:'rgba(255,255,255,.02)',border:'1px solid var(--b1)',borderRadius:'var(--r)',textAlign:'left',transition:'.2s',cursor:'default'}}>
              <div style={{width:34,height:34,borderRadius:8,background:'rgba(74,127,245,.1)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:15}}>{f.icon}</div>
              <div style={{flex:1}}>
                <div style={{fontSize:12,fontWeight:500,color:'var(--t1)',marginBottom:2}}>{f.title}</div>
                <div style={{fontSize:11,color:'var(--t3)',lineHeight:1.35}}>{f.sub}</div>
              </div>
              <div style={{fontSize:13,color:'var(--t3)',flexShrink:0}}>→</div>
            </div>
          ))}
        </div>

        {/* CTA */}
        <button
          onClick={() => goTo('login')}
          style={{display:'inline-flex',alignItems:'center',gap:9,padding:'14px 38px',background:'var(--blue-g)',borderRadius:50,color:'#fff',fontSize:14,fontWeight:500,letterSpacing:'.01em',boxShadow:'0 0 50px rgba(74,127,245,.2)',transition:'.25s',animation:'fu .6s .3s ease both',border:'none',cursor:'pointer'}}
        >
          Get Started <span>→</span>
        </button>
      </div>
    </div>
  )
}
