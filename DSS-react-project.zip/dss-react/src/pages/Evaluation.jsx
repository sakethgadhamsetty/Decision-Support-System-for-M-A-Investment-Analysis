import { useState, useEffect } from 'react'
import Sidebar from '../components/Sidebar.jsx'

const NOTE_PH = 'Analyze by message or written info. Add reasoning if needed. (Optional)'

const QUANT = [
  { n:1, title:'Revenue Quality' },
  { n:2, title:'Growth Quality' },
  { n:3, title:'Margin Quality' },
  { n:4, title:'Cash Reality' },
  { n:5, title:'Leverage Risk' },
  { n:6, title:'Value Creation Test' },
  { n:7, title:'Valuation Discipline' },
]

const QUAL = [
  { n:8,  title:'Market Cycle Timing',      type:'dd',  opts:['Select','Early','Mid','Late'] },
  { n:9,  title:'Synergies',                type:'syn' },
  { n:11, title:'Exit Strategy',            type:'dd',  opts:['Select','High','Medium','Low'] },
  { n:12, title:'Governance & Management',  type:'dd',  opts:['Select','Low','Medium','High'] },
  { n:13, title:'ESG Viability',            type:'dd',  opts:['Select','Low','Medium','High'] },
  { n:14, title:'External Risk',            type:'dd',  opts:['Select','Low','Medium','High'] },
  { n:15, title:'Execution Plan',           type:'yn' },
]

function initState() {
  const s = {}
  ;[...QUANT, ...QUAL].forEach(t => { s[t.n] = { done: false, skipped: false, pf: null, score: '', mode: '0-10', note: '', val: '' } })
  return s
}

export default function Evaluation({ goTo, currentDeal, chatHistory, setChatHistory }) {
  const [termState, setTermState] = useState(initState())

  const allTerms = [...QUANT, ...QUAL].map(t => t.n)
  const done = allTerms.filter(n => termState[n]?.done).length
  const skipped = allTerms.filter(n => termState[n]?.skipped).length
  const sysPass = allTerms.filter(n => termState[n]?.pf === 'pass').length
  const sysFail = allTerms.filter(n => termState[n]?.pf === 'fail').length
  const pct = Math.round((done / 14) * 100)

  const setField = (n, field, value) => {
    setTermState(prev => ({ ...prev, [n]: { ...prev[n], [field]: value } }))
  }

  const markDone = (n) => {
    setTermState(prev => ({ ...prev, [n]: { ...prev[n], done: true, skipped: false } }))
  }

  const skipTerm = (n) => {
    setTermState(prev => ({ ...prev, [n]: { ...prev[n], done: false, skipped: true, pf: null } }))
  }

  const onScore = (n, val, mode) => {
    const threshold = mode === '0-10' ? 5 : 50
    const num = parseFloat(val)
    const pf = val === '' ? null : num >= threshold ? 'pass' : 'fail'
    setTermState(prev => ({ ...prev, [n]: { ...prev[n], score: val, pf, done: val !== '' } }))
  }

  // Gate 10 status
  const g10status = done === 0 ? { color:'var(--t3)', text:'Awaiting evaluation inputs' }
    : done < 7 ? { color:'var(--amber)', text:`${done} of 14 terms completed — continue evaluation` }
    : done < 14 ? { color:'var(--blue)', text:`${done} of 14 terms completed — evaluation in progress` }
    : { color:'var(--green)', text:'All terms evaluated — ready to generate DSS output' }

  return (
    <div style={{position:'fixed',inset:0,display:'flex',flexDirection:'row',overflow:'hidden'}}>
      <Sidebar chatHistory={chatHistory} setChatHistory={setChatHistory} onNewChat={() => goTo('chat')} goTo={goTo}/>

      <div style={{flex:1,display:'flex',flexDirection:'column',minWidth:0,overflow:'hidden'}}>
        {/* Topbar */}
        <div style={{height:48,borderBottom:'1px solid var(--b1)',display:'flex',alignItems:'center',padding:'0 16px',gap:9,flexShrink:0}}>
          <button onClick={() => goTo('chat')} style={{background:'none',border:'none',color:'var(--t2)',cursor:'pointer',fontSize:16}}>←</button>
          <span style={{fontSize:13,fontWeight:500,color:'var(--t1)',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
            {currentDeal.name || 'Deal'} — Structured Evaluation
          </span>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,padding:'3px 8px',borderRadius:5,border:'1px solid var(--bb)',background:'var(--bd)',color:'var(--blue)',textTransform:'uppercase',letterSpacing:'.08em'}}>DSS Evaluation</span>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:'var(--blue)',background:'var(--bd)',border:'1px solid var(--bb)',borderRadius:6,padding:'3px 10px',whiteSpace:'nowrap'}}>{done} / 15</span>
          <div style={{width:130,height:4,background:'var(--s3)',borderRadius:2,overflow:'hidden'}}>
            <div style={{height:'100%',background:'var(--blue-g)',borderRadius:2,width:`${pct}%`,transition:'width .4s ease'}}/>
          </div>
        </div>

        <div style={{flex:1,overflowY:'auto',padding:24}}>
          <div style={{maxWidth:900,margin:'0 auto'}}>

            {/* Deal context bar */}
            <div style={{background:'var(--s1)',border:'1px solid var(--b1)',borderRadius:'var(--r)',padding:'14px 18px',marginBottom:24,display:'flex',alignItems:'center',gap:12}}>
              <div style={{width:36,height:36,borderRadius:9,background:'var(--bd)',border:'1px solid var(--bb)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:18}}>🏢</div>
              <div style={{flex:1}}>
                <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.1em',marginBottom:3}}>Active Deal</div>
                <div style={{fontSize:14,fontWeight:500,color:'var(--t1)'}}>{currentDeal.name || '—'}</div>
                <div style={{fontSize:11,color:'var(--t3)',marginTop:1}}>{currentDeal.type || 'Complete all 15 evaluation terms below'}</div>
              </div>
              <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:10,color:'var(--t3)'}}>15 Terms · 2 Sections</div>
            </div>

            {/* Section 1 */}
            <SectionHead badge="Section 1" badgeType="quant" title="Quantitative Terms" sub="Score required · 7 terms"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:12,marginBottom:28}}>
              {QUANT.map(t => (
                <QuantCard key={t.n} term={t} state={termState[t.n]} onScore={onScore} skipTerm={skipTerm} setField={setField} markDone={markDone}/>
              ))}
            </div>

            {/* Gate 10 */}
            <SectionHead badge="System Derived" badgeType="sys" title="Final Decision Gate" sub="Auto-calculated · No manual input"/>
            <div style={{background:'var(--s1)',border:'1px solid var(--b1)',borderRadius:'var(--rl)',padding:20,marginBottom:28}}>
              <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:16}}>
                <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,padding:'3px 10px',borderRadius:5,background:'var(--gn)',border:'1px solid var(--gnb)',color:'var(--green)',textTransform:'uppercase',letterSpacing:'.08em'}}>Gate 10</span>
                <span style={{fontFamily:"'Playfair Display',serif",fontSize:16,fontWeight:700,color:'#fff'}}>Final Decision Gate</span>
                <span style={{fontSize:11,color:'var(--t3)',fontStyle:'italic',marginLeft:'auto'}}>Automatically calculated from all inputs</span>
              </div>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr 1fr 1fr',gap:10,marginBottom:14}}>
                {[
                  {num:sysPass,label:'Passed',color:'var(--green)'},
                  {num:sysFail,label:'Failed',color:'var(--red)'},
                  {num:skipped,label:'Skipped',color:'var(--t3)'},
                  {num:done,label:'Completed',color:'var(--blue)'},
                ].map(({num,label,color})=>(
                  <div key={label} style={{background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:'var(--r)',padding:14,textAlign:'center'}}>
                    <div style={{fontFamily:"'Playfair Display',serif",fontSize:28,fontWeight:700,lineHeight:1,color,marginBottom:4}}>{num}</div>
                    <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.08em'}}>{label}</div>
                  </div>
                ))}
              </div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'center',gap:10,padding:12,background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:'var(--r)'}}>
                <div style={{width:8,height:8,borderRadius:'50%',background:g10status.color,animation:'pulse 2s infinite'}}/>
                <span style={{fontSize:12,fontWeight:500,color:g10status.color}}>{g10status.text}</span>
              </div>
            </div>

            {/* Section 2 */}
            <SectionHead badge="Section 2" badgeType="qual" title="Judgement-Mapped Terms" sub="Dropdown-based · 7 terms"/>
            <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(280px,1fr))',gap:12,marginBottom:28}}>
              {QUAL.map(t => (
                <QualCard key={t.n} term={t} state={termState[t.n]} skipTerm={skipTerm} setField={setField} markDone={markDone}/>
              ))}
            </div>

          </div>
        </div>

        {/* Footer */}
        <div style={{borderTop:'1px solid var(--b1)',padding:'14px 24px',flexShrink:0,background:'var(--s1)'}}>
          <div style={{maxWidth:900,margin:'0 auto'}}>
            <div style={{fontSize:11,color:'var(--t3)',fontStyle:'italic',marginBottom:10,textAlign:'center',lineHeight:1.5}}>
              All evaluations must be based on analyzed message, written information, and uploaded data.
            </div>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',gap:14}}>
              <div style={{fontSize:12,color:'var(--t3)'}}>Progress: <span style={{color:'var(--t2)',fontWeight:500}}>{done} of 15</span> terms evaluated</div>
              <div style={{fontSize:11,color:'var(--t3)',fontStyle:'italic'}}>Submit to compute Final DSS Decision.</div>
              <button onClick={()=>alert('DSS Decision computation initiated.\n\nResult page coming next phase.')}
                style={{display:'flex',alignItems:'center',gap:8,padding:'11px 24px',background:'var(--blue-g)',borderRadius:10,color:'#fff',fontSize:13,fontWeight:500,border:'none',cursor:'pointer',boxShadow:'0 4px 20px rgba(74,127,245,.2)'}}>
                Generate DSS Decision Output →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function SectionHead({ badge, badgeType, title, sub }) {
  const cols = { quant:['var(--bd)','var(--bb)','var(--blue)'], qual:['var(--gd)','rgba(201,168,76,.25)','var(--gold)'], sys:['var(--gn)','var(--gnb)','var(--green)'] }
  const [bg,border,color] = cols[badgeType]
  return (
    <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:16,paddingBottom:10,borderBottom:'1px solid var(--b1)'}}>
      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,padding:'3px 10px',borderRadius:5,textTransform:'uppercase',letterSpacing:'.08em',fontWeight:500,background:bg,border:`1px solid ${border}`,color}}>{badge}</span>
      <span style={{fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:700,color:'#fff'}}>{title}</span>
      <span style={{fontSize:11,color:'var(--t3)',marginLeft:'auto'}}>{sub}</span>
    </div>
  )
}

function QuantCard({ term, state, onScore, skipTerm, setField, markDone }) {
  const [mode, setMode] = useState('0-10')
  const pfTag = state?.pf === 'pass' ? {bg:'var(--gn)',border:'var(--gnb)',color:'var(--green)',text:'PASS'}
    : state?.pf === 'fail' ? {bg:'var(--rd)',border:'var(--rb)',color:'var(--red)',text:'FAIL'}
    : {bg:'var(--s2)',border:'var(--b1)',color:'var(--t3)',text:'PENDING'}

  return (
    <div style={{background:'var(--s1)',border:`1px solid ${state?.done?'rgba(34,197,94,.25)':state?.skipped?'var(--b1)':'var(--b1)'}`,borderRadius:'var(--rl)',padding:16,opacity:state?.skipped?.5:1,transition:'.2s'}}>
      <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:12}}>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:4,padding:'2px 7px'}}>TERM {String(term.n).padStart(2,'0')}</span>
        <span style={{fontSize:13,fontWeight:600,color:'var(--t1)',flex:1,margin:'0 10px'}}>{term.title}</span>
        <div style={{width:18,height:18,borderRadius:'50%',border:`1.5px solid ${state?.done?'var(--gnb)':'var(--b2)'}`,background:state?.done?'var(--gn)':state?.skipped?'var(--s3)':'transparent',display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,flexShrink:0,color:state?.done?'var(--green)':state?.skipped?'var(--t3)':'transparent'}}>
          {state?.done?'✓':state?.skipped?'—':''}
        </div>
      </div>

      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:10}}>
        <input type="number" min="0" max={mode==='0-10'?10:100} placeholder="0" value={state?.score||''}
          onChange={e => onScore(term.n, e.target.value, mode)}
          style={{width:60,background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,padding:'7px 10px',fontSize:14,fontWeight:500,color:'var(--t1)',textAlign:'center'}}/>
        <div style={{display:'flex',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,overflow:'hidden',flexShrink:0}}>
          {['0-10','0-100','%'].map(m=>(
            <button key={m} onClick={()=>{setMode(m);if(state?.score)onScore(term.n,state.score,m)}}
              style={{padding:'5px 8px',fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:mode===m?'var(--blue)':'var(--t3)',background:mode===m?'var(--s3)':'transparent',border:'none',cursor:'pointer',whiteSpace:'nowrap'}}>
              {m}
            </button>
          ))}
        </div>
        {/* System-only PASS/FAIL tag */}
        <div style={{marginLeft:'auto',padding:'4px 10px',borderRadius:6,fontFamily:"'JetBrains Mono',monospace",fontSize:9,fontWeight:500,border:`1px solid ${pfTag.border}`,color:pfTag.color,background:pfTag.bg,letterSpacing:'.06em'}}>
          {pfTag.text}
        </div>
      </div>

      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.08em',display:'block',marginBottom:5}}>Notes</span>
      <textarea placeholder={NOTE_PH} value={state?.note||''} onChange={e=>setField(term.n,'note',e.target.value)}
        style={{width:'100%',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,padding:'8px 11px',fontSize:11,color:'var(--t1)',resize:'none',minHeight:56,lineHeight:1.5}}/>
      <div style={{display:'flex',justifyContent:'flex-end',marginTop:8}}>
        <button onClick={()=>skipTerm(term.n)} style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',background:'none',border:'none',cursor:'pointer',letterSpacing:'.06em',textTransform:'uppercase'}}>Skip →</button>
      </div>
    </div>
  )
}

function QualCard({ term, state, skipTerm, setField, markDone }) {
  const [yn, setYN] = useState(null)

  const handleDD = (val) => { setField(term.n,'val',val); if(val!=='Select') markDone(term.n) }
  const handleYN = (val) => { setYN(val); setField(term.n,'val',val); markDone(term.n) }

  return (
    <div style={{background:'var(--s1)',border:`1px solid ${state?.done?'rgba(34,197,94,.25)':'var(--b1)'}`,borderRadius:'var(--rl)',padding:16,opacity:state?.skipped?.5:1,transition:'.2s'}}>
      <div style={{display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:12}}>
        <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:4,padding:'2px 7px'}}>TERM {String(term.n).padStart(2,'0')}</span>
        <span style={{fontSize:13,fontWeight:600,color:'var(--t1)',flex:1,margin:'0 10px'}}>{term.title}</span>
        <div style={{width:18,height:18,borderRadius:'50%',border:`1.5px solid ${state?.done?'var(--gnb)':'var(--b2)'}`,background:state?.done?'var(--gn)':state?.skipped?'var(--s3)':'transparent',display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,flexShrink:0,color:state?.done?'var(--green)':state?.skipped?'var(--t3)':'transparent'}}>
          {state?.done?'✓':state?.skipped?'—':''}
        </div>
      </div>

      <div style={{marginBottom:10}}>
        {term.type === 'dd' && (
          <select onChange={e=>handleDD(e.target.value)} defaultValue="Select"
            style={{width:'100%',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,padding:'8px 12px',fontSize:13,color:'var(--t1)',WebkitAppearance:'none'}}>
            {term.opts.map(o=><option key={o} value={o}>{o}</option>)}
          </select>
        )}
        {term.type === 'syn' && (
          <div>
            <div style={{fontSize:11,color:'var(--t2)',marginBottom:6}}>Standalone viable?</div>
            <div style={{display:'flex',gap:6,marginBottom:8}}>
              {['yes','no'].map(v=>(
                <button key={v} onClick={()=>handleYN(v)}
                  style={{flex:1,padding:8,borderRadius:7,fontSize:12,fontWeight:500,cursor:'pointer',background:yn===v?(v==='yes'?'var(--gn)':'var(--rd)'):'var(--s2)',border:`1px solid ${yn===v?(v==='yes'?'var(--gnb)':'var(--rb)'):'var(--b1)'}`,color:yn===v?(v==='yes'?'var(--green)':'var(--red)'):'var(--t2)'}}>
                  {v.charAt(0).toUpperCase()+v.slice(1)}
                </button>
              ))}
            </div>
            <input type="text" placeholder="Cost synergy % (e.g. 12%)" onChange={e=>setField(term.n,'val',e.target.value)}
              style={{width:'100%',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,padding:'8px 12px',fontSize:13,color:'var(--t1)',marginBottom:8}}/>
          </div>
        )}
        {term.type === 'yn' && (
          <div style={{display:'flex',gap:6}}>
            {['yes','no'].map(v=>(
              <button key={v} onClick={()=>handleYN(v)}
                style={{flex:1,padding:8,borderRadius:7,fontSize:12,fontWeight:500,cursor:'pointer',background:yn===v?(v==='yes'?'var(--gn)':'var(--rd)'):'var(--s2)',border:`1px solid ${yn===v?(v==='yes'?'var(--gnb)':'var(--rb)'):'var(--b1)'}`,color:yn===v?(v==='yes'?'var(--green)':'var(--red)'):'var(--t2)'}}>
                {v.charAt(0).toUpperCase()+v.slice(1)}
              </button>
            ))}
          </div>
        )}
      </div>

      <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.08em',display:'block',marginBottom:5}}>Notes</span>
      <textarea placeholder={NOTE_PH} value={state?.note||''} onChange={e=>setField(term.n,'note',e.target.value)}
        style={{width:'100%',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,padding:'8px 11px',fontSize:11,color:'var(--t1)',resize:'none',minHeight:56,lineHeight:1.5}}/>
      <div style={{display:'flex',justifyContent:'flex-end',marginTop:8}}>
        <button onClick={()=>skipTerm(term.n)} style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',background:'none',border:'none',cursor:'pointer',letterSpacing:'.06em',textTransform:'uppercase'}}>Skip →</button>
      </div>
    </div>
  )
}
