import { useState, useRef, useEffect } from 'react'
import Sidebar from '../components/Sidebar.jsx'

const AiSvg = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
  </svg>
)

export default function Chat({ goTo, currentDeal, setCurrentDeal, chatHistory, setChatHistory }) {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [files, setFiles] = useState([])
  const [typing, setTyping] = useState(false)
  const [title, setTitle] = useState('New Analysis')
  const chatRef = useRef(null)

  useEffect(() => { chatRef.current?.scrollTo(0, chatRef.current.scrollHeight) }, [messages, typing])

  const addToHistory = (text) => {
    const words = text.split(' ').filter(w => w.length > 2)
    const name = words.slice(0, 3).join(' ') || 'New Deal'
    const type = text.toLowerCase().includes('lbo') ? 'LBO' : text.toLowerCase().includes('merger') ? 'Merger' : 'M&A'
    setCurrentDeal({ name, type: type + ' · Analysis' })
    setTitle(name)
    setChatHistory(prev => {
      const updated = prev.map(c => ({...c, active: false}))
      return [{ name, type: type + ' · Analysis', active: true }, ...updated].slice(0, 8)
    })
  }

  const send = () => {
    if (!input.trim() && files.length === 0) return
    const txt = input.trim()
    const fs = [...files]
    setMessages(prev => [...prev, { role: 'u', text: txt, files: fs }])
    setInput('')
    setFiles([])
    addToHistory(txt)
    setTyping(true)
    setTimeout(() => {
      setTyping(false)
      setMessages(prev => [...prev, { role: 'a', text: null, isAI: true }])
    }, 1700)
  }

  const handleKey = (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send() } }

  const newChat = () => {
    setMessages([]); setTitle('New Analysis')
    setChatHistory(prev => prev.map(c => ({...c, active: false})))
  }

  const loadChat = (i) => {
    setChatHistory(prev => prev.map((c,j) => ({...c, active: j===i})))
    setTitle(chatHistory[i].name)
    setCurrentDeal({ name: chatHistory[i].name, type: chatHistory[i].type })
    setMessages([
      { role: 'u', text: `Analyze the ${chatHistory[i].name} deal.`, files: [] },
      { role: 'a', text: null, isAI: true }
    ])
  }

  return (
    <div style={{position:'fixed',inset:0,display:'flex',flexDirection:'row',overflow:'hidden'}}>
      <Sidebar chatHistory={chatHistory} setChatHistory={setChatHistory} onNewChat={newChat} onLoadChat={loadChat} goTo={goTo}/>

      <div style={{flex:1,display:'flex',flexDirection:'column',minWidth:0,overflow:'hidden'}}>
        {/* Topbar */}
        <div style={{height:48,borderBottom:'1px solid var(--b1)',display:'flex',alignItems:'center',padding:'0 14px',gap:9,flexShrink:0}}>
          <span style={{fontSize:13,fontWeight:500,color:'var(--t1)',flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{title}</span>
          <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,padding:'3px 8px',borderRadius:5,border:'1px solid var(--bb)',background:'var(--bd)',color:'var(--blue)',textTransform:'uppercase',letterSpacing:'.08em'}}>InvestIQ DSS</span>
        </div>

        {/* Chat scroll */}
        <div ref={chatRef} style={{flex:1,overflowY:'auto',display:'flex',flexDirection:'column'}}>
          <div style={{maxWidth:700,width:'100%',margin:'0 auto',padding:'24px 18px 14px',flex:1,display:'flex',flexDirection:'column'}}>
            {messages.length === 0 && (
              <div style={{flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',textAlign:'center',animation:'fu .4s ease both'}}>
                <div style={{width:50,height:50,borderRadius:14,background:'var(--blue-g)',display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 18px',boxShadow:'0 0 44px rgba(74,127,245,.2)'}}>
                  <svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
                </div>
                <div style={{fontFamily:"'Playfair Display',serif",fontSize:24,fontWeight:700,color:'#fff',marginBottom:7}}>Start a Deal Analysis</div>
                <div style={{fontSize:13,color:'var(--t3)',lineHeight:1.6,maxWidth:360,margin:'0 auto'}}>Describe the M&A deal or investment you want to evaluate. Attach financial documents and reports for deeper analysis.</div>
              </div>
            )}

            <div style={{display:'flex',flexDirection:'column',gap:20,marginBottom:14}}>
              {messages.map((m, i) => (
                <div key={i} style={{display:'flex',gap:11,animation:'mi .25s ease both'}}>
                  <div style={{width:28,height:28,borderRadius:'50%',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:600,background:m.role==='u'?'var(--blue-g)':'var(--s2)',border:m.role==='a'?'1px solid var(--b1)':'none',color:m.role==='u'?'#fff':'var(--t2)'}}>
                    {m.role === 'u' ? 'A' : <AiSvg/>}
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:11,fontWeight:600,color:'var(--t1)',marginBottom:4}}>{m.role==='u'?'You':'InvestIQ DSS'}</div>
                    {m.role === 'u' && m.text && (
                      <div style={{fontSize:13,color:'var(--t1)',lineHeight:1.7,background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:'3px 11px 11px 11px',padding:'10px 14px',display:'inline-block',maxWidth:'86%'}}>{m.text}</div>
                    )}
                    {m.role === 'a' && m.isAI && <AIResponse goTo={goTo}/>}
                    {m.files && m.files.length > 0 && (
                      <div style={{display:'flex',gap:6,flexWrap:'wrap',marginTop:7}}>
                        {m.files.map((f,fi) => (
                          <div key={fi} style={{display:'flex',alignItems:'center',gap:5,padding:'4px 8px',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:6,fontSize:11,color:'var(--t2)'}}>📎 {f.name}</div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {typing && (
                <div style={{display:'flex',gap:11,animation:'mi .25s ease both'}}>
                  <div style={{width:28,height:28,borderRadius:'50%',flexShrink:0,display:'flex',alignItems:'center',justifyContent:'center',background:'var(--s2)',border:'1px solid var(--b1)',color:'var(--t2)'}}><AiSvg/></div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:11,fontWeight:600,color:'var(--t1)',marginBottom:4}}>InvestIQ DSS</div>
                    <div style={{display:'flex',gap:4,alignItems:'center',padding:'8px 0'}}>
                      {[0,.18,.36].map((d,i)=><div key={i} style={{width:6,height:6,borderRadius:'50%',background:'var(--t3)',animation:`td 1.2s ${d}s infinite`}}/>)}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Input */}
        <div style={{padding:'11px 18px 16px',flexShrink:0}}>
          <div style={{maxWidth:700,margin:'0 auto'}}>
            {files.length > 0 && (
              <div style={{display:'flex',gap:6,flexWrap:'wrap',marginBottom:7}}>
                {files.map((f,i)=>(
                  <div key={i} style={{display:'flex',alignItems:'center',gap:5,padding:'5px 8px',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:6}}>
                    <span style={{fontSize:11,color:'var(--t2)',maxWidth:100,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.name}</span>
                    <button onClick={()=>setFiles(prev=>prev.filter((_,j)=>j!==i))} style={{background:'none',border:'none',color:'var(--t3)',cursor:'pointer',fontSize:11}}>✕</button>
                  </div>
                ))}
              </div>
            )}
            <div style={{background:'var(--s1)',border:'1px solid var(--b1)',borderRadius:'var(--rl)',overflow:'hidden'}}>
              <textarea value={input} onChange={e=>setInput(e.target.value)} onKeyDown={handleKey}
                placeholder="Describe the deal you want to analyze..." rows={1}
                style={{width:'100%',background:'transparent',color:'var(--t1)',fontSize:13,lineHeight:1.6,padding:'12px 14px 8px',resize:'none',minHeight:48,maxHeight:170,display:'block'}}/>
              <div style={{display:'flex',alignItems:'center',padding:'7px 9px',gap:5,borderTop:'1px solid var(--b1)'}}>
                <label style={{width:28,height:28,borderRadius:6,background:'transparent',color:'var(--t3)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',fontSize:14}}>
                  📎<input type="file" multiple style={{display:'none'}} onChange={e=>setFiles(prev=>[...prev,...Array.from(e.target.files)])}/>
                </label>
                <label style={{width:28,height:28,borderRadius:6,background:'transparent',color:'var(--t3)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',fontSize:14}}>
                  🖼️<input type="file" accept="image/*" multiple style={{display:'none'}} onChange={e=>setFiles(prev=>[...prev,...Array.from(e.target.files)])}/>
                </label>
                <label style={{width:28,height:28,borderRadius:6,background:'transparent',color:'var(--t3)',display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',fontSize:14}}>
                  📄<input type="file" accept=".pdf,.doc,.docx,.xls,.xlsx,.csv" multiple style={{display:'none'}} onChange={e=>setFiles(prev=>[...prev,...Array.from(e.target.files)])}/>
                </label>
                <span style={{flex:1}}/>
                <span style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',whiteSpace:'nowrap'}}>↵ Send · ⇧↵ New line</span>
                <button onClick={send} disabled={!input.trim() && files.length===0}
                  style={{width:30,height:30,borderRadius:7,background:(!input.trim()&&files.length===0)?'var(--s3)':'var(--blue-g)',color:'#fff',display:'flex',alignItems:'center',justifyContent:'center',border:'none',cursor:(!input.trim()&&files.length===0)?'not-allowed':'pointer',flexShrink:0,fontSize:14}}>
                  →
                </button>
              </div>
            </div>
            <div style={{textAlign:'center',fontSize:11,color:'var(--t3)',marginTop:7}}>DSS analyzes M&A, private equity, growth and strategic investment decisions</div>
          </div>
        </div>
      </div>
    </div>
  )
}

function AIResponse({ goTo }) {
  return (
    <div style={{fontSize:13,color:'var(--t1)',lineHeight:1.7}}>
      I have received your deal query. To begin the structured evaluation, please provide the following parameters:
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:6,margin:'12px 0'}}>
        {['Deal / Company Name','Sector & Industry','Deal Structure','Estimated Deal Size','Target Revenue / EBITDA','Strategic Rationale'].map(item => (
          <div key={item} style={{display:'flex',alignItems:'center',gap:7,padding:'8px 11px',background:'var(--s1)',border:'1px solid var(--b1)',borderRadius:8}}>
            <div style={{width:4,height:4,borderRadius:'50%',background:'var(--blue)',flexShrink:0}}/>
            <span style={{fontSize:12,color:'var(--t2)'}}>{item}</span>
          </div>
        ))}
      </div>
      Once you provide the deal details, I will open the structured evaluation framework.
      <br/><br/>
      <button onClick={goTo.bind(null,'eval')}
        style={{display:'inline-flex',alignItems:'center',gap:8,padding:'10px 20px',background:'var(--blue-g)',borderRadius:9,color:'#fff',fontSize:13,fontWeight:500,border:'none',cursor:'pointer',boxShadow:'0 4px 20px rgba(74,127,245,.2)'}}>
        Begin Structured Evaluation →
      </button>
    </div>
  )
}
