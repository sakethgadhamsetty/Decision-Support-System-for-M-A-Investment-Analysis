import { useState } from 'react'
import Landing from './pages/Landing.jsx'
import Login from './pages/Login.jsx'
import Chat from './pages/Chat.jsx'
import Evaluation from './pages/Evaluation.jsx'

export default function App() {
  const [page, setPage] = useState('landing')
  const [currentDeal, setCurrentDeal] = useState({ name: '', type: '' })
  const [chatHistory, setChatHistory] = useState([])

  const goTo = (p) => setPage(p)

  return (
    <>
      {page === 'landing'    && <Landing goTo={goTo} />}
      {page === 'login'      && <Login goTo={goTo} />}
      {page === 'chat'       && (
        <Chat
          goTo={goTo}
          currentDeal={currentDeal}
          setCurrentDeal={setCurrentDeal}
          chatHistory={chatHistory}
          setChatHistory={setChatHistory}
        />
      )}
      {page === 'eval'       && (
        <Evaluation
          goTo={goTo}
          currentDeal={currentDeal}
          chatHistory={chatHistory}
          setChatHistory={setChatHistory}
        />
      )}
    </>
  )
}
