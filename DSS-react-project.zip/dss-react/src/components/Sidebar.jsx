export default function Sidebar({ chatHistory, setChatHistory, onNewChat, onLoadChat, goTo }) {
  const colors = ['rgba(74,127,245,.15)','rgba(34,197,94,.15)','rgba(201,168,76,.15)','rgba(239,68,68,.15)','rgba(167,139,250,.15)']
  const tc = ['#4a7ff5','#22c55e','#c9a84c','#ef4444','#a78bfa']

  return (
    <aside style={{width:252,background:'var(--s1)',borderRight:'1px solid var(--b1)',display:'flex',flexDirection:'column',flexShrink:0,overflow:'hidden'}}>
      {/* Top */}
      <div style={{padding:'13px 9px 9px',borderBottom:'1px solid var(--b1)'}}>
        <div style={{display:'flex',alignItems:'center',gap:8,padding:'5px 7px',marginBottom:9}}>
          <div style={{width:28,height:28,borderRadius:7,background:'var(--blue-g)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
            <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/>
            </svg>
          </div>
          <span style={{fontFamily:"'Playfair Display',serif",fontSize:15,fontWeight:700,color:'#fff',whiteSpace:'nowrap'}}>DSS</span>
        </div>
        <button onClick={onNewChat} style={{width:'100%',display:'flex',alignItems:'center',gap:7,padding:'8px 9px',borderRadius:8,background:'transparent',border:'1px solid var(--b1)',color:'var(--t2)',fontSize:12,fontWeight:500,cursor:'pointer',whiteSpace:'nowrap',transition:'.2s'}}>
          + New Analysis
        </button>
      </div>

      {/* Search */}
      <div style={{padding:'9px 9px 5px'}}>
        <input placeholder="Search analyses..." style={{width:'100%',background:'var(--s2)',border:'1px solid var(--b1)',borderRadius:7,padding:'7px 10px',fontSize:11,color:'var(--t1)'}}/>
      </div>

      {/* History */}
      <div style={{flex:1,overflowY:'auto',padding:'5px 7px 10px'}}>
        {chatHistory.length === 0 ? (
          <div style={{padding:'18px 7px',textAlign:'center'}}>
            <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.1em',marginBottom:6}}>No analyses yet</div>
            <div style={{fontSize:11,color:'var(--t3)',lineHeight:1.5}}>Start a new analysis</div>
          </div>
        ) : (
          <div>
            <div style={{fontFamily:"'JetBrains Mono',monospace",fontSize:9,color:'var(--t3)',textTransform:'uppercase',letterSpacing:'.1em',padding:'4px 7px 5px'}}>Recent</div>
            {chatHistory.map((c, i) => (
              <div key={i} onClick={() => onLoadChat && onLoadChat(i)}
                style={{display:'flex',alignItems:'center',gap:7,padding:'6px 7px',borderRadius:7,cursor:'pointer',background:c.active?'var(--s3)':'transparent',marginBottom:1,transition:'.15s'}}>
                <div style={{width:18,height:18,borderRadius:5,display:'flex',alignItems:'center',justifyContent:'center',fontSize:9,fontWeight:600,flexShrink:0,background:colors[i%5],color:tc[i%5]}}>
                  {c.name[0].toUpperCase()}
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:11,color:'var(--t1)',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{c.name}</div>
                  <div style={{fontSize:10,color:'var(--t3)',marginTop:1}}>{c.type}</div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <div style={{padding:9,borderTop:'1px solid var(--b1)'}}>
        <div style={{display:'flex',alignItems:'center',gap:8,padding:'7px 8px',borderRadius:8,cursor:'pointer'}}>
          <div style={{width:30,height:30,borderRadius:'50%',background:'var(--blue-g)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:600,color:'#fff',flexShrink:0}}>A</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:12,fontWeight:500,color:'var(--t1)'}}>Analyst</div>
            <div style={{fontSize:10,color:'var(--t3)'}}>DSS · InvestIQ</div>
          </div>
          <button onClick={() => goTo('login')} style={{width:26,height:26,borderRadius:6,background:'transparent',border:'none',color:'var(--t3)',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',fontSize:12}}>→</button>
        </div>
      </div>
    </aside>
  )
}
